from geometry_msgs.msg import Pose, PoseWithCovariance, Quaternion, Pose2D, PoseStamped, Twist

import numpy as np
import math
import os
import yaml
import time


def euler_from_quaternion(x, y, z, w):

    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = math.atan2(t0, t1)

    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch_y = math.asin(t2)

    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw_z = math.atan2(t3, t4)

    return roll_x, pitch_y, yaw_z  # in radians


def quaternion_from_euler(roll, pitch, yaw):

    qx = np.sin(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) - \
        np.cos(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)
    qy = np.cos(roll/2) * np.sin(pitch/2) * np.cos(yaw/2) + \
        np.sin(roll/2) * np.cos(pitch/2) * np.sin(yaw/2)
    qz = np.cos(roll/2) * np.cos(pitch/2) * np.sin(yaw/2) - \
        np.sin(roll/2) * np.sin(pitch/2) * np.cos(yaw/2)
    qw = np.cos(roll/2) * np.cos(pitch/2) * np.cos(yaw/2) + \
        np.sin(roll/2) * np.sin(pitch/2) * np.sin(yaw/2)

    return [qx, qy, qz, qw]


# calculating angle
def to360(angle, _int=False):
    angle = round((angle*180)/math.pi, 4)
    if _int:
        angle = int(angle)
    if angle < 0:
        angle = angle+360
    return angle


# calculate post position
def P2D_to_full(Pose, frame_id='not_imp'):
    p = PoseStamped()
    p.header.frame_id = frame_id
    if type(Pose) != PoseStamped:
        p.pose.position.x = Pose.x
        p.pose.position.y = Pose.y
        p.pose.position.z = 0.
        quaternion = quaternion_from_euler(0, 0, Pose.theta)

        p.pose.orientation.x = quaternion[0]
        p.pose.orientation.y = quaternion[1]
        p.pose.orientation.z = quaternion[2]
        p.pose.orientation.w = quaternion[3]
    else:
        p.pose = Pose.pose

    return p


def full_to_P2D(Pose):
    p = Pose2D()
    p.x = Pose.pose.position.x
    p.y = Pose.pose.position.y
    rot_q = Pose.pose.orientation
    (roll, pitch, p.theta) = euler_from_quaternion(
        rot_q.x, rot_q.y, rot_q.z, rot_q.w)
    return p


def abs_pos(P: Pose2D(), origin, full_pos=False):
    P.x = P.x - origin[0]
    P.y = P.y - origin[1]
    if full_pos:
        P = P2D_to_full(P)
    return P


# convert arena position to Pixel
def pos2pix(x, y, res, h=None):
    x = int(x/res)
    y = int(y/res)
    #y = int(h - (y/res))
    return [x, y]


# convert positiom on map image to arena position
def pix2pos(x, y, res, h=None):
    x = x*res
    #y = (h-y)*res
    y = y*res
    return [x, y]


# check  probability distribution
def check_P2D(P, ns=''):

    if type(P) == Pose2D:
        pass
    elif type(P) == PoseStamped or type(P) == Pose or type(P) == PoseWithCovariance:
        P = full_to_P2D(P)
    elif type(P) == tuple or type(P) == list:
        i = Pose2D()
        i.x = P[0]
        i.y = P[1]
        P = i
    else:
        print('Type of Position is not valid, should be Pose2D or PoseStamped')
    return P


# check pose validity
def check_fullPose(P, ns=''):
    if type(P) == PoseStamped or type(P) == Pose or type(P) == PoseWithCovariance:
        pass
    elif type(P) == Pose2D:
        P = P2D_to_full(P)
    else:
        print('Type of Position is not valid, should be Pose2D or PoseStamped')
    return P


def norm(A, B):
    A = check_P2D(A)
    B = check_P2D(B)
    norm = np.linalg.norm(np.array([A.x, A.y])
                          - np.array([B.x, B.y]))
    return round(norm, 4)


class map_data:
    def __init__(self):
        path = os.path.dirname(__file__)
        home = os.path.abspath(os.path.join(os.path.join(os.path.join(os.path.join(os.path.join(os.path.join(
            os.path.join(path, os.pardir), os.pardir), os.pardir), os.pardir), os.pardir), os.pardir), os.pardir))
        share = os.path.join(home, 'share/')
        with open(share+'raw_map.yaml') as f:
            raw_map = yaml.safe_load(f)
        self.w = raw_map['w']
        self.h = raw_map['h']
        self.res = raw_map['res']
        self.max_x = raw_map['max_x']
        self.max_y = raw_map['max_y']
        self.occ_grid = np.array(raw_map['occ_grid'])
        self.origin = raw_map['origin']


class robot_info:
    def __init__(self, mapInfo, radius):
        self.max_x = mapInfo.max_x
        self.max_y = mapInfo.max_y

        self.radius = radius
        self.rows = int(self.radius*mapInfo.occ_grid.shape[0]/mapInfo.max_y)
        self.cols = int(self.radius*mapInfo.occ_grid.shape[1]/mapInfo.max_x)
        self.start = Pose2D()
        self.goal = Pose2D()


# check if the path is free
def is_free(P, robot_info, mapInfo):
    P = check_P2D(P)
    rows = robot_info.rows
    cols = robot_info.cols
    stride = np.ones((2*rows, 2*cols))
    [pix_x, pix_y] = pos2pix(P.x, P.y, mapInfo.res, mapInfo.occ_grid.shape[0])
    check = mapInfo.occ_grid[pix_y-rows:pix_y+rows, pix_x-cols:pix_x+cols]
    return False if np.max(np.multiply(stride, check)) > 0 else True


# checks if the selected path is valid
def is_valid(P, robot_info, mapInfo, log=False):
    valid = False
    P = check_P2D(P)
    if robot_info.radius < P.x < mapInfo.max_x-robot_info.radius and robot_info.radius < P.y < mapInfo.max_y-robot_info.radius:
        free = is_free(P, robot_info, mapInfo)
        if free:
            valid = True
    else:
        if log:
            print(
                " Position is not valid, current position x = %s and y= %s" % (P.x, P.y))
    return valid


def in_dict(dictinory, Pose_coord, robot_info, mapInfo, check_dist=0.8):
    in_dict = False

    check_dist = 2*robot_info.radius * check_dist / mapInfo.res
    for key in dictinory:
        loc = list(map(int, key.split(',')))

        if np.linalg.norm(np.array([Pose_coord[1]-loc[0], Pose_coord[0]-loc[1]])) < check_dist:
            in_dict = True
            break

    return in_dict


# calculate distance to destination/next goal from current pose
def heuristic(current, goal):
    goal = check_fullPose(goal)
    current = check_fullPose(current)
    return abs(current.pose.position.x-goal.pose.position.x)+abs(current.pose.position.y-goal.pose.position.y)


# check if neighboring cells are empty or have obstacles
def get_neighbours(current_pos, robot_info, mapInfo, directions):
    current_pos = check_P2D(current_pos)
    neighbours = list()
    increment = 2*math.pi/directions
    theta = current_pos.theta
    for i in range(directions):
        neighbour = Pose2D()
        neighbour.x = current_pos.x+1.9*(robot_info.radius*math.cos(theta))
        neighbour.y = current_pos.y+1.9*(robot_info.radius*math.sin(theta))
        neighbour.theta = theta
        theta += increment
        if is_valid(neighbour, robot_info, mapInfo):
            neighbours.append(P2D_to_full(neighbour, frame_id=str(i)))

    return neighbours
