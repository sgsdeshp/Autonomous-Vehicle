import yaml
from PIL import Image
import numpy as np
with open('raw_map.yaml','r') as f:
    data = yaml.safe_load(f)
array = np.array(data['occ_grid'],dtype=np.uint8)
img = Image.fromarray(array)
img.save('debug.png')
