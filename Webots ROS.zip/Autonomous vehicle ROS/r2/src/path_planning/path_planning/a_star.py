from numpy.lib.function_base import angle
import rclpy
from rclpy.impl.rcutils_logger import Once
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, Twist, Pose2D
from nav_msgs.msg import Odometry


import numpy as np
from queue import PriorityQueue
from math import atan2, sin, cos


from path_planning.util_funcs import full_to_P2D, P2D_to_full, pos2pix, norm, check_P2D, map_data, robot_info, in_dict, heuristic, get_neighbours, abs_pos

V_MAX = 0.22
W_MAX = 0.4
RADIUS = 0.15
DELTA = 0.2
NEIGHBOURS = 8
X_OFFSET = 0.2
Y_OFFSET = -0.2
controller_constants = {'kv': 0.19, 'kw': 0.86}


def algorithm(mapInfo, robot):

    count = 0
    open_set = PriorityQueue()
    came_from = {}
    # get start/current position from RViz
    robot.start = P2D_to_full(robot.start)
    # get destination position from RViz
    robot.goal = P2D_to_full(robot.goal)
    print(robot.start)
    print(robot.goal)
    # calculate coordinates
    coord = pos2pix(robot.start.pose.position.x,
                    robot.start.pose.position.y, mapInfo.res, mapInfo.h)
    goal_coord = pos2pix(robot.goal.pose.position.x,
                         robot.goal.pose.position.y, mapInfo.res, mapInfo.h)
    # distance from start point
    g_score = np.ones((mapInfo.h, mapInfo.w))*np.inf
    g_score[coord[1]][coord[0]] = 0
    # distance to destination
    f_score = np.ones((mapInfo.h, mapInfo.w))*np.inf
    f_score[coord[1]][coord[0]] = heuristic(robot.start, robot.goal)

    close_set_hash = {}
    robot.start = P2D_to_full(
        robot.start, frame_id='%s,%s' % (coord[1], coord[0]))
    open_set_hash = {robot.start.header.frame_id: robot.start}

    robot.goal = P2D_to_full(robot.goal, frame_id='%s,%s' %
                             (goal_coord[1], goal_coord[0]))
    robot_goal = {robot.goal.header.frame_id: robot.goal}
    open_set.put((0, count, robot.start))

    while not open_set.empty():
        current = open_set.get()[2]

        current_coord = pos2pix(current.pose.position.x,
                                current.pose.position.y, mapInfo.res, mapInfo.h)

        open_set_hash.pop(current.header.frame_id)
        close_set_hash['%s,%s' %
                       (current_coord[1], current_coord[0])] = current

        if in_dict(robot_goal, current_coord, robot, mapInfo, check_dist=0.8):
            reconstruct_from = '%s,%s' % (current_coord[1], current_coord[0])
            break

        for neighbour in get_neighbours(current, robot, mapInfo, directions=NEIGHBOURS):
            # convert positions between map data and pose on arena
            nbr_coord = pos2pix(neighbour.pose.position.x,
                                neighbour.pose.position.y, mapInfo.res, mapInfo.h)
            neighbour = P2D_to_full(
                neighbour, frame_id='%s,%s' % (nbr_coord[1], nbr_coord[0]))
            if in_dict(close_set_hash, nbr_coord, robot, mapInfo, check_dist=0.5):
                continue
            temp_g_score = g_score[coord[1]][coord[0]] + robot.radius
            if temp_g_score < g_score[nbr_coord[1]][nbr_coord[0]]:
                came_from['%s,%s' % (nbr_coord[1], nbr_coord[0])] = current
                g_score[nbr_coord[1]][nbr_coord[0]] = temp_g_score
                f_score[nbr_coord[1]][nbr_coord[0]] = temp_g_score + \
                    heuristic(neighbour, robot.goal)
                if not in_dict(open_set_hash, nbr_coord, robot, mapInfo, check_dist=0.5):
                    count += 1
                    open_set.put(
                        (f_score[nbr_coord[1]][nbr_coord[0]], count, neighbour))
                    open_set_hash[neighbour.header.frame_id] = neighbour
    whole_path = []
    whole_path.append(check_P2D(robot.goal))
    path_length = 0
    # searching for path
    if bool(came_from):
        while reconstruct_from in came_from:
            path_length += norm(whole_path[-1], came_from[reconstruct_from])
            whole_path.append(check_P2D(came_from[reconstruct_from]))
            reconstruct_from = came_from[reconstruct_from].header.frame_id
        whole_path = whole_path[::-1]

    else:
        print('\nPath not found.')

    return whole_path


# get angle to destination
def getOmega(angle2goal, theta):
    relative = angle2goal-theta
    if relative < 0 and relative < -3.1415:
        return 1*min(W_MAX, abs(angle2goal-theta))
    if relative > 0 and relative > 3.1415:
        return -1*min(W_MAX, abs(angle2goal-theta))
    else:
        return np.sign(relative)*min(W_MAX, abs(angle2goal-theta))


# set/cal linear and angular velocity, setting threshold for position and angle
def simple_controller(referance, curr_pose):
    speed = Twist()
    delta_x = referance.x - curr_pose.x
    delta_y = referance.y - curr_pose.y
    #angle2goal = atan2(delta_y, delta_x) - curr_pose.theta
    angle2goal = atan2(delta_y, delta_x)
    if abs(angle2goal-curr_pose.theta) > 0.05:
        speed.angular.z = getOmega(angle2goal, curr_pose.theta)
        speed.linear.x = 0.
    elif norm(curr_pose, referance) > 0.05:
        #print('Distance To Goal: ',norm(curr_pose,referance))
        speed.angular.z = 0.
        speed.linear.x = V_MAX

    return speed


# creating publishing node to publish data to robot i.e sending commands to robot
class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('a_star')
        self.mapInfo = map_data()
        self.robot = robot_info(self.mapInfo, RADIUS)
        self.onGoal = True
        self.i = 1
        self.rate = self.create_rate(1)
        self.get_logger().info('Waiting for Goal . . .')
        # Localization by EKF filtered odometry
        #self.getOdom = self.create_subscription(Odometry,'/odometry/filtered',self.getOdom_callback,10)
        # localization by simple odometry
        self.getOdom = self.create_subscription(
            Odometry, '/odom', self.getOdom_callback, 10)
        self.getGoal = self.create_subscription(
            PoseStamped, '/goal_pose', self.getGoal_callback, 10)
        self.pubVel = self.create_publisher(Twist, '/cmd_vel', 10)
    # receving goal coordinates from RViz

    def getGoal_callback(self, msg):
        if msg:
            self.get_logger().info('Goal recieved.')
            self.onGoal = False
            if not self.onGoal:
                self.rate.sleep()
                self.robot.goal = abs_pos(check_P2D(msg), self.mapInfo.origin)
                self.robot.start = self.pose
                print(self.robot.goal)
                print(self.robot.start)
                self.whole_path = algorithm(self.mapInfo, self.robot)
                print('WHOLE PATH :\n', self.whole_path)
                self.getOdom

    # getting localization data
    def getOdom_callback(self, msg):
        speed = Twist()
        self.pose = abs_pos(check_P2D(msg.pose), self.mapInfo.origin)
        self.pose.x += X_OFFSET
        self.pose.y += Y_OFFSET
        print("Current Location: ", self.pose)
        if not self.onGoal:
            if self.i < len(self.whole_path)-1:
                #print("Current pose: ", self.pose)
                speed = simple_controller(self.whole_path[self.i], self.pose)
                #speed = improved_controllel(self.whole_path[self.i],self.pose, controller_constants)
                if norm(self.whole_path[self.i], self.pose) < 0.1:
                    self.i += 1

            if self.i == len(self.whole_path)-1:
                speed = simple_controller(self.whole_path[self.i], self.pose)
                if norm(self.whole_path[self.i], self.pose) < 0.05:
                    self.i += 1

            if self.i == len(self.whole_path):
                speed = Twist()
                #print("Goal Reached. Waiting for next Goal . . . ")
                self.get_logger().info("Goal Reached. Waiting for next Goal . . .", once=True)

            self.pubVel.publish(speed)


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    minimal_publisher.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
