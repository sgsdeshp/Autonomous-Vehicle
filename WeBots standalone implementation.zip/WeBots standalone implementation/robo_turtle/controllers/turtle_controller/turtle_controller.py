"""turtle_controller controller."""


from controller import Supervisor
import pathfinding
import numpy as np
import matplotlib.pyplot as plt
import math
import time


# convert coordinates to cell
def get_grid_id(x_current, z_current):
    x_id = int(round((x_current - 0.125) / .25, 0) + 1)
    z_id = int(round((z_current - 0.125) / .25, 0) + 1)
    return (x_id, z_id)

# convert cell to coodinate
def get_cords_from_id(x_id, z_id):
    x_cord = (0.25 * (x_id - 1)) + 0.125
    z_cord = (0.25 * (z_id - 1)) + 0.125
    return z_cord, x_cord

# obstacle detection using a set threshold
def detect_walls(mapping_mode=False):
    threshold = 600
    if mapping_mode:
        threshold = 800
    left = ds_left.getValue() < threshold
    front = ds_front.getValue() < threshold
    right = ds_right.getValue() < threshold
    return left, front, right

# map generation
def create_map():
    # get all position and orientation values
    theta, delta_theta = get_angle_to_goal(0, 0)
    realposition = robotnode.getPosition()
    x_current = realposition[0]
    z_current = realposition[2]
    x_id, z_id = get_grid_id(x_current, z_current)
    left, front, right = detect_walls(mapping_mode=True)
    back = None
    # identifying cells
    west_tile = [x_id - 1, z_id]
    north_tile = [x_id, z_id - 1]
    east_tile = [x_id + 1, z_id]
    south_tile = [x_id, z_id + 1]
    grid_list = [west_tile, north_tile, east_tile, south_tile]
    sensor_list = np.array([left, front, right, back])
    # for theta = 0, there is no index shift e.g. grid_list[0] is east_tile
    index_shift = int(- round(theta / (math.pi / 2), 0))
    # logically rotate distance sensors
    sensor_list = np.roll(sensor_list, index_shift)
    for i in range(4):
        if sensor_list[i] is None:  # skip if back sensor is None
            continue
        x = int(grid_list[i][0])
        z = int(grid_list[i][1])
        if map_matrix[z, x] != 1:
            map_matrix[z, x] = int(sensor_list[i])

# calculating angle to goal
def get_angle_to_goal(x_goal, z_goal):
    pos = robotnode.getPosition()
    rot = robotnode.getOrientation()
    theta = math.atan2(rot[2], rot[8])
    delta_x = pos[0] - x_goal
    delta_z = pos[2] - z_goal
    theta_goal = math.atan2(delta_x, delta_z)
    delta_theta = theta_goal - theta
    #print(theta, theta_goal, delta_theta)
    return theta, delta_theta

# robot motion
def move(x_goal, z_goal):
    create_map()
    x_id_old, z_id_old = start
    while robot.step(timestep) != -1:
        theta, delta_theta = get_angle_to_goal(x_goal, z_goal)
        realposition = robotnode.getPosition()
        x_current = realposition[0]
        z_current = realposition[2]
        x_id, z_id = get_grid_id(x_current, z_current)
        if [x_id, z_id] != [x_id_old, z_id_old]:
            create_map()
            print(x_id, z_id)
            print(map_matrix)
        x_id_old, z_id_old = x_id, z_id
        left, front, right = detect_walls(mapping_mode=False)
        # turn speed modulation
        turn_speed = max_speed * max(min(delta_theta, 1), -1)
        if abs(delta_theta) > 0.01:  # turning
            left_motor.setVelocity(-turn_speed)
            right_motor.setVelocity(turn_speed)
        else:  # moving forward
            realposition = robotnode.getPosition()
            x_current = realposition[0]
            z_current = realposition[2]
            delta_x = ((x_current)-(x_goal))**2
            delta_z = ((z_current)-(z_goal))**2
            distance = math.sqrt(delta_x + delta_z)
            if front:
                print("Obstacle detected! Calculating new Path")
                stop()
                collsiion = True
                break
            # checking for when close to next waypoint with tolerance of 0.01m
            if distance < 0.01:
                print("Waypoint reached")
                stop()
                collsiion = False
                break
            # individual wheel speed modulation during forward motion
            left_motor.setVelocity(max_speed - abs(turn_speed) - turn_speed)
            right_motor.setVelocity(max_speed - abs(turn_speed) + turn_speed)
    create_map()
    if map_matrix.any():
        if map_matrix[end[0]][end[1]] == 1:
            print("Obstacle detected at Destination")
            np.save("map.npy", map_matrix)
            raise ValueError("Obstacle detected at Destination")
    print(map_matrix)

    return collsiion

# vehicle stop
def stop():
    left_motor.setVelocity(0)
    right_motor.setVelocity(0)

# path planning
def create_waypoints():
    table = np.array(map_matrix)  # [1:-1, 1:-1]
    table[table == 2] = 0
    # call to pathfinding.py an implementation of a-star algorithm
    navigation_path = pathfinding.find(table, start, end)
    # print(navigation_path)
    cords = pathfinding.get_corner_cods(navigation_path, start)
    print(cords)
    real_cords = [get_cords_from_id(z, x) for z, x in cords]
    return real_cords


# instance of class supervisor
robot = Supervisor()
robotnode = robot.getSelf()

pi = 22/7
# get the time step of the current world.
timestep = 32
max_speed = 6.28

wheel_radius = 0.033
wheel_circum = 2 * pi * wheel_radius
# rotations required for covering 0.25 m
rot_forward = 0.25 / wheel_circum
# expected pos-sensor reading for 0.25 m
pos_forward = 2 * pi * rot_forward
# wheelbase ie the distance between the 2 wheels m
wheelbase = 0.16
# turning radius/circumference of  vehicle
veh_circum = 2 * pi * (wheelbase / 2)
# rotations required for covering 90 degree turn
rot_turn = (veh_circum / 4) / wheel_circum
# Expected pos-sensor reading for 90 degree turn
pos_turn = 2 * pi * rot_turn

# creating motor instances
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
# allow continuous rotation of wheel
left_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setPosition(float('inf'))
right_motor.setVelocity(0.0)


# creating distance sensor instance
ds_front = robot.getDevice('distance sensor front')
ds_front.enable(timestep)
ds_left = robot.getDevice('distance sensor left')
ds_left.enable(timestep)
ds_right = robot.getDevice('distance sensor right')
ds_right.enable(timestep)
# creating position-sensor instances
left_ps = robot.getDevice('left wheel sensor')
left_ps.enable(timestep)
right_ps = robot.getDevice('right wheel sensor')
right_ps.enable(timestep)

# creating camera instance
camera = robot.getDevice('camera')
camera.enable(timestep)

# position sensor initial value
left_wval = left_ps.getValue()
right_wval = right_ps.getValue()
# take one simulation step to give each sensor the first value
robot.step(timestep)
# Mapping matrix 0 = open tile, 1 = wall, 2 = unknown ,
map_matrix = np.array([[2]*12] * 12)
map_matrix[1, 1] = 0
#map_matrix[1,2] = 0
map_matrix[0] = 1
map_matrix[-1] = 1
map_matrix[:, 0] = 1
map_matrix[:, -1] = 1
try:
    map_matrix = np.load("map.npy")
    print("Map Loaded")
except Exception:
    print("No map found")
# end = [z, x] or [row, column] in the map matrix
end = [10, 1]
cost = 1
if map_matrix.any():
    if map_matrix[end[0]][end[1]] == 1:
        print("Obstacle detected at Destination")
        raise ValueError("Obstacle detected at Destination")


create_map()
while True:
    realposition = robotnode.getPosition()
    x_current = realposition[0]
    z_current = realposition[2]
    x_id, z_id = get_grid_id(x_current, z_current)
    start = [z_id, x_id]
    real_cords = create_waypoints()
    print(real_cords)
    print(start, real_cords[0])
    for i in real_cords[1:]:
        print(f"moving to {i[0], i[1]}")
        collision = move(i[0], i[1])
        if collision:
            break
    if not collision:
        break

print("Destination reached! HOORAY")
np.save("map.npy", map_matrix)
# final robot position
left_motor.setVelocity(0)
right_motor.setVelocity(0)
