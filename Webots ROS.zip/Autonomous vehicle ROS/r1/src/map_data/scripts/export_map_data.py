#!/usr/bin/python3

# ROS Imports
PKG = 'map_data'
import roslib; roslib.load_manifest(PKG)
import rospy
from nav_msgs.msg import OccupancyGrid

# Python Imports
import numpy as np
import os
from scipy import ndimage
import yaml,io

class map_data:
  def __init__(self):
    #global origin, w_ns, w_radius
    msg = rospy.wait_for_message('/map', OccupancyGrid, timeout=None)
    self.w = msg.info.width
    self.h = msg.info.height
    self.res = msg.info.resolution
    self.max_x = self.w*self.res
    self.max_y = self.h*self.res
    self.occ_grid = np.array(msg.data, dtype=np.uint8).reshape((self.h,self.w))
    #self.occ_grid = np.flip(self.occ_grid,axis=0)
    self.origin = [msg.info.origin.position.x, msg.info.origin.position.y]
    r = rospy.get_param('/export_map_data/diameter')
    itr = int(r/self.res)
    self.occ_grid = ndimage.binary_dilation(self.occ_grid, iterations=itr).astype(self.occ_grid.dtype)
    self.occ_grid = np.where(self.occ_grid==1, int(100), self.occ_grid)

if __name__ == '__main__':
  try:
    path = os.path.dirname(__file__)
    home = os.path.abspath(os.path.join(os.path.join(os.path.join(os.path.join(path,os.pardir),os.pardir),os.pardir), os.pardir))
    share = os.path.join(home,'share/')
    rospy.init_node('export_map_data')
    mapInfo = map_data()
    data = {
      'w': mapInfo.w,
      'h': mapInfo.h,
      'res': mapInfo.res,
      'max_x': mapInfo.max_x,
      'max_y': mapInfo.max_y,
      'occ_grid': mapInfo.occ_grid.tolist(),
      'origin': mapInfo.origin
    }
    with io.open(share+'raw_map.yaml', 'w', encoding='utf8') as outfile:
      yaml.dump(data, outfile, default_flow_style=False, allow_unicode=True)
      rospy.loginfo("Map data exported. You can clean this process.")

  except rospy.ROSInterruptException:
      pass
