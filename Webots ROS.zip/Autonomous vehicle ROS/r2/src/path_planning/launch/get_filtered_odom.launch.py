from launch import LaunchDescription
from ament_index_python.packages import get_package_share_directory
import launch_ros.actions
import os
import yaml
from launch.substitutions import EnvironmentVariable
import pathlib
import launch.actions
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import Command, LaunchConfiguration

def generate_launch_description():
  #pkg_share = FindPackageShare(package='path_planning').find('path_planning')
  pkg_share = '/home/robo/robo_project/r2/src/path_planning/'
  robot_localization_file_path = os.path.join(pkg_share, 'config/ekf.yaml') 
  default_launch_dir = os.path.join(pkg_share, 'launch')
  use_sim_time = LaunchConfiguration('use_sim_time')
  declare_use_sim_time_cmd = DeclareLaunchArgument(
    name='use_sim_time',
    default_value='True',
    description='Use simulation clock if true')
    
  start_robot_localization_cmd = Node(
    package='robot_localization',
    executable='ekf_node',
    name='ekf_filter_node',
    output='screen',
    parameters=[robot_localization_file_path, 
    {'use_sim_time': use_sim_time}])
  
  ld = LaunchDescription()
  ld.add_action(start_robot_localization_cmd)
  return ld
  


