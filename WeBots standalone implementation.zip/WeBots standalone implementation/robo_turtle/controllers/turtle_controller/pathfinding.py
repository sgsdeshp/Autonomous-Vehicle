import math
import numpy as npy


def find(table, start, end):
    # normalization and threshold for comparing heuristic values
    balance_weightage = 1
    # objects for class cell
    start_node = Cell(None, tuple(start))
    destination_cell = Cell(None, tuple(end))
    # represented with 2 in map_matrix
    unvisited_cells = list()

    visited_cells = list()

    unvisited_cells.append(start_node)
    # extraction no. of rows and columns
    num_rows, num_colms = npy.shape(table)
    iterations = 0
    # setting limit to possible iteration as presaution
    iterations_limit = 10**100
    while len(unvisited_cells):
        iterations += 1
        current_cell = unvisited_cells[0]
        current_index = 0
        # checks / identify adjescent nodes/blocks
        direction_flags = (
            [1, 0],
            [0, 1],
            [-1, 0],
            [0, -1],
        )
        # max iteation limit check
        if iterations > iterations_limit:
            print("iterations overloaded")
            return closest_path(current_cell, table)
        # updating current location
        for cell in unvisited_cells:
            if cell.lowest_weightage < current_cell.lowest_weightage:
                current_cell = cell
                current_index = unvisited_cells.index(cell)

        visited_cells.append(current_cell)
        unvisited_cells.pop(current_index)
        # identifying and returning the shortest path by re-tracing previously visited cells
        if current_cell == destination_cell:
            return closest_path(current_cell, table)

        valid_cells_list = []
        flag_couter = 0
        while flag_couter < len(direction_flags):
            new_pos = direction_flags[flag_couter]
            flag_couter += 1
            cell_pos = (current_cell.pos[0] + new_pos[0],
                        current_cell.pos[1] + new_pos[1])
            # checking if cell is valid
            if (cell_pos[0] < 0 or
                    cell_pos[1] < 0):
                continue
            # verifying cell is within map boundary
            if (cell_pos[0] > (num_rows - 1) or
                        cell_pos[1] > (num_colms - 1)
                    ):
                continue
            # checking closed path / ignoring  cells with obstacles for path finding
            if table[cell_pos[0]][cell_pos[1]] != 0:
                continue

            new_node = Cell(current_cell, cell_pos)
            valid_cells_list.append(new_node)

        valid_cells_counter = 0
        while valid_cells_counter < len(valid_cells_list):
            c = valid_cells_list[valid_cells_counter]
            valid_cells_counter += 1

            if len([visited_child for visited_child in visited_cells if visited_child == c]) > 0:
                continue

            c.exact_weightage = current_cell.exact_weightage + balance_weightage

            c.heuristic_dist(destination_cell)
            c.lowest_weightage = c.exact_weightage + c.h_weightage

            if len([i for i in unvisited_cells if c == i and c.exact_weightage > i.exact_weightage]) > 0:
                continue

            unvisited_cells.append(c)


def closest_path(current_cell, table):
    navigation_path = list([])
    num_rows, num_colms = npy.shape(table)
    res_matrix = []

    for x in range(num_rows):
        for y in range(num_colms):
            if len(res_matrix) > x:
                res_matrix[x].append(-2)
            else:
                res_matrix.append([-2])
    current = current_cell

    while current is not None:
        navigation_path.append(current.pos)
        current = current.pre_station_cell

    navigation_path = navigation_path[::-1]
    start_value = 0

    for k in range(len(navigation_path)):
        res_matrix[navigation_path[k][0]][navigation_path[k][1]] = start_value
        start_value += 1
    idl_matrix = refactor_matrix(res_matrix)
    k = sorted(idl_matrix, key=lambda i: i['index'])
    mapped_path = [i['points'] for i in k]

    return mapped_path

# convert ideal cell values to coordinates


def refactor_matrix(res_matrix):
    idl_matrix = []
    for x, i in enumerate(res_matrix):
        for y, j in enumerate(i):
            if j > -1:
                idl_matrix.append({'index': j, "points": (x, y)})
    return idl_matrix


# for smother motion of robot, ignore members of the same axis
def get_corner_cods(nav_path, start_pos=(0, 0)):
    corner_cods = []
    common_axis = None
    for cell in nav_path:
        if cell == nav_path[0]:
            corner_cods.append(cell)
        if common_axis is None:
            if cell[0] == start_pos[0]:
                common_axis = 0
            elif cell[1] == start_pos[1]:
                common_axis = 1
        else:
            if start_pos[common_axis] != cell[common_axis]:
                common_axis = 1 if common_axis == 0 else 0
                if start_pos not in corner_cods:
                    corner_cods.append(start_pos)
        if cell == nav_path[-1]:
            corner_cods.append(cell)
        start_pos = cell

    return corner_cods


class Cell:
    exact_weightage = 0
    # heuristic weight
    h_weightage = 0
    lowest_weightage = 0

    def __init__(self, *args):
        self.pre_station_cell = args[0]
        self.pos = args[1]

    def __eq__(self, new):
        return self.pos == new.pos
    # Square root ignored

    def heuristic_dist(self, destination_cell_obj):
        dist = (math.pow((self.pos[0] - destination_cell_obj.pos[0]), 2) +
                math.pow((self.pos[1] - destination_cell_obj.pos[1]), 2))
        self.h_weightage = dist
